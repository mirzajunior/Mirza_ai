# AI Chat Backend v2 (Vercel)

```
ai-chat-backend/
├── api/index.ts        rute: /api/chat, /api/compare, /api/autotune, /api/models, /api/health
├── lib/
│   ├── autotune.ts     pilih suhu & parameter sesuai jenis percakapan
│   ├── llm.ts          OpenRouter atau server lokal (Ollama, LM Studio)
│   ├── compare.ts      penilaian sederhana untuk bandingkan model
│   └── personas.ts     gaya AI: santai, tegas, guru, programmer
├── package.json  tsconfig.json  vercel.json  .env.example
```

## Deploy
1. `npm install`
2. Upload ke GitHub (folder `api` dan `lib` harus ada), impor di vercel.com.
3. Settings → Environment Variables: isi `OPENROUTER_API_KEY` (opsi lain ada di `.env.example`).
4. Deploy ulang.

## Pakai
Semua rute (kecuali health) butuh header `Authorization: Bearer <APP_TOKEN>` kalau `APP_TOKEN` diisi.

`POST /api/chat`
```json
{ "messages": [{ "role": "user", "content": "Buatkan fungsi JS untuk..." }],
  "model": "nousresearch/hermes-3-llama-3.1-70b",
  "persona": "programmer",
  "autotune": true }
```
- `autotune`: `true` (otomatis), `false` (matikan), atau `"precise"` / `"balanced"` / `"creative"`.
- Balasan: `{ reply, model, ms, autotune: { context, params, notes } }`.

`POST /api/compare`: sama seperti chat, tambah `"models": ["model-a", "model-b"]` (2 sampai 5).

`POST /api/autotune`: lihat parameter yang akan dipilih tanpa memanggil model.

Model lokal: isi `LOCAL_BASE_URL` (alamat Ollama/LM Studio yang bisa diakses dari internet), lalu pakai nama model berawalan `local:`, misal `local:llama3`.

Server tidak menyimpan percakapan apa pun.
