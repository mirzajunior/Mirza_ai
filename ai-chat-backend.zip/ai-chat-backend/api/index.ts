import express, { NextFunction, Request, Response } from "express";
import cors from "cors";
import { autoTune, detectContext, Strategy } from "../lib/autotune";
import { callModel, ChatMessage } from "../lib/llm";
import { scoreAnswer } from "../lib/compare";
import { PERSONAS } from "../lib/personas";

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

const DEFAULT_MODEL = process.env.DEFAULT_MODEL || "nousresearch/hermes-3-llama-3.1-70b";
const allowedModels = (): string[] => {
  const list = (process.env.MODELS || DEFAULT_MODEL).split(",").map((s) => s.trim()).filter(Boolean);
  return list.includes(DEFAULT_MODEL) ? list : [DEFAULT_MODEL, ...list];
};
const modelOk = (m: string) => m.startsWith("local:") ? !!process.env.LOCAL_BASE_URL : allowedModels().includes(m);

function isValidMessages(x: unknown): x is ChatMessage[] {
  return Array.isArray(x) && x.length > 0 && x.length <= 100 &&
    x.every((m) => m && (m.role === "user" || m.role === "assistant") &&
      typeof m.content === "string" && m.content.length > 0 && m.content.length <= 20000);
}

function auth(req: Request, res: Response, next: NextFunction) {
  const t = process.env.APP_TOKEN;
  if (t && req.headers.authorization !== `Bearer ${t}`) return res.status(401).json({ error: "Token salah atau tidak ada" });
  next();
}

function prep(body: any) {
  const messages = body?.messages;
  if (!isValidMessages(messages)) return { error: "Format 'messages' tidak valid" } as const;
  const last = [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const history = messages.map((m) => m.content);
  const persona = typeof body.persona === "string" && PERSONAS[body.persona] ? body.persona : "default";
  const system = (typeof body.system === "string" && body.system.trim()) || process.env.SYSTEM_PROMPT || PERSONAS[persona];
  const tune = body.autotune === false ? null
    : autoTune({ message: last, history, strategy: (["precise", "balanced", "creative"].includes(body.autotune) ? body.autotune : "adaptive") as Strategy });
  const maxTokens = Math.min(Math.max(Number(body.max_tokens) || 2048, 64), 8192);
  return { messages, last, system, tune, maxTokens } as const;
}

app.get("/api/health", (_req, res) => { res.json({ ok: true }); });

app.get("/api/models", auth, (_req, res) => {
  res.json({ default: DEFAULT_MODEL, models: allowedModels(), local: !!process.env.LOCAL_BASE_URL, personas: Object.keys(PERSONAS) });
});

// Analisis saja: lihat parameter apa yang akan dipilih AutoTune
app.post("/api/autotune", auth, (req, res) => {
  const p = prep(req.body);
  if ("error" in p) return res.status(400).json({ error: p.error });
  res.json(autoTune({ message: p.last, history: p.messages.map((m) => m.content), strategy: req.body.autotune }));
});

// Chat biasa dengan AutoTune otomatis
app.post("/api/chat", auth, async (req, res) => {
  const p = prep(req.body);
  if ("error" in p) return res.status(400).json({ error: p.error });
  const model = (typeof req.body.model === "string" && req.body.model) || DEFAULT_MODEL;
  if (!modelOk(model)) return res.status(400).json({ error: "Model tidak ada di daftar yang diizinkan", allowed: allowedModels() });
  try {
    const r = await callModel({ model, system: p.system, messages: p.messages as ChatMessage[], params: p.tune?.params, maxTokens: p.maxTokens });
    res.json({ reply: r.reply, model: r.model, ms: r.ms, autotune: p.tune ? { context: p.tune.context, confidence: p.tune.confidence, params: p.tune.params, notes: p.tune.notes } : null });
  } catch (e: any) {
    res.status(e.status && e.status < 600 ? e.status : 502).json({ error: e.message });
  }
});

// Bandingkan beberapa model untuk pertanyaan yang sama (maks 5)
app.post("/api/compare", auth, async (req, res) => {
  const p = prep(req.body);
  if ("error" in p) return res.status(400).json({ error: p.error });
  const models: string[] = Array.isArray(req.body.models) ? [...new Set<string>(req.body.models.filter((m: unknown) => typeof m === "string"))].slice(0, 5) : [];
  if (models.length < 2) return res.status(400).json({ error: "Isi 'models' minimal 2 model" });
  const bad = models.filter((m) => !modelOk(m));
  if (bad.length) return res.status(400).json({ error: "Model tidak diizinkan: " + bad.join(", "), allowed: allowedModels() });

  const ctx = detectContext(p.last, p.messages.map((m) => m.content)).context;
  const results = await Promise.all(models.map(async (model) => {
    try {
      const r = await callModel({ model, system: p.system, messages: p.messages as ChatMessage[], params: p.tune?.params, maxTokens: p.maxTokens });
      return { model, ok: true, reply: r.reply, ms: r.ms, ...scoreAnswer(r.reply, r.ms, ctx) };
    } catch (e: any) {
      return { model, ok: false, error: e.message };
    }
  }));
  results.sort((a: any, b: any) => (b.score ?? -1) - (a.score ?? -1));
  res.json({ context: ctx, note: "Skor hanya heuristik (kelengkapan, struktur, kecepatan), bukan penilaian mutlak.", results });
});

export default app;
