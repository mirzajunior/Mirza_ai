// Penilaian sederhana dan transparan untuk membandingkan jawaban beberapa model.
// Ini hanya heuristik; nilai tertinggi belum tentu jawaban terbaik untuk kamu.
import type { ContextType } from "./autotune";

export interface Scored { score: number; breakdown: { kelengkapan: number; struktur: number; kecepatan: number } }

export function scoreAnswer(reply: string, ms: number, context: ContextType): Scored {
  const len = reply.trim().length;
  const target = context === "conversational" ? 300 : context === "code" ? 700 : 900;
  const kelengkapan = Math.round(Math.min(len / target, 1) * 50);

  let struktur = 0;
  if (/\n\n/.test(reply)) struktur += 6;
  if (/^\s*([-*]|\d+\.)\s/m.test(reply)) struktur += 6;
  if (context === "code" ? /```/.test(reply) : /[.!?]\s/.test(reply)) struktur += 8;
  struktur = Math.min(struktur, 20);

  const kecepatan = Math.round(Math.max(0, Math.min(1, (12000 - ms) / 10000)) * 30);
  return { score: kelengkapan + struktur + kecepatan, breakdown: { kelengkapan, struktur, kecepatan } };
}
