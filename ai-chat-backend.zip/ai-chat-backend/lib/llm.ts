// Pemanggil model: OpenRouter (default) atau server lokal kompatibel OpenAI (Ollama, LM Studio, dll.)
import type { TuneParams } from "./autotune";

export interface ChatMessage { role: "user" | "assistant"; content: string }

export const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";

export interface CallOptions {
  model: string;
  system: string;
  messages: ChatMessage[];
  params?: Partial<TuneParams>;
  maxTokens?: number;
}
export interface CallResult { reply: string; model: string; ms: number; usage?: unknown }

export async function callModel(o: CallOptions): Promise<CallResult> {
  const local = o.model.startsWith("local:");
  const base = local ? process.env.LOCAL_BASE_URL : OPENROUTER_URL;
  if (!base) throw new Error("LOCAL_BASE_URL belum diatur untuk model lokal");
  const url = local ? base.replace(/\/$/, "") + "/chat/completions" : base;
  const key = local ? process.env.LOCAL_API_KEY || "" : process.env.OPENROUTER_API_KEY;
  if (!local && !key) throw new Error("OPENROUTER_API_KEY belum diatur di server");

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (key) headers.Authorization = `Bearer ${key}`;
  if (!local) {
    headers["HTTP-Referer"] = process.env.APP_URL || "https://localhost";
    headers["X-Title"] = process.env.APP_NAME || "AI Chat";
  }

  const body: Record<string, unknown> = {
    model: local ? o.model.slice(6) : o.model,
    messages: [{ role: "system", content: o.system }, ...o.messages],
    max_tokens: o.maxTokens ?? 2048,
    ...(o.params || {}),
  };

  const t0 = Date.now();
  const r = await fetch(url, { method: "POST", headers, body: JSON.stringify(body) });
  const data: any = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(data?.error?.message || `Error ${r.status}`), { status: r.status });
  return { reply: data?.choices?.[0]?.message?.content ?? "", model: data?.model ?? o.model, ms: Date.now() - t0, usage: data?.usage };
}
