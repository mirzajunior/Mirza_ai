// AutoTune: memilih parameter sampling (suhu dll.) sesuai jenis percakapan, sebelum model dipanggil.
// Implementasi sendiri, ide umum: kode butuh presisi, kreatif butuh variasi.

export type ContextType = "code" | "creative" | "analytical" | "conversational";

export interface TuneParams {
  temperature: number;
  top_p: number;
  top_k: number;
  frequency_penalty: number;
  presence_penalty: number;
  repetition_penalty: number;
}

export interface TuneResult {
  context: ContextType;
  confidence: number; // 0..1
  scores: Record<ContextType, number>;
  params: TuneParams;
  notes: string[];
}

const PROFILES: Record<ContextType, TuneParams> = {
  code:           { temperature: 0.2, top_p: 0.85, top_k: 40, frequency_penalty: 0.1, presence_penalty: 0.0, repetition_penalty: 1.05 },
  analytical:     { temperature: 0.4, top_p: 0.88, top_k: 50, frequency_penalty: 0.2, presence_penalty: 0.1, repetition_penalty: 1.08 },
  conversational: { temperature: 0.75, top_p: 0.9, top_k: 60, frequency_penalty: 0.1, presence_penalty: 0.1, repetition_penalty: 1.0 },
  creative:       { temperature: 1.05, top_p: 0.95, top_k: 80, frequency_penalty: 0.4, presence_penalty: 0.5, repetition_penalty: 1.12 },
};

const PATTERNS: Record<ContextType, RegExp[]> = {
  code: [
    /```/, /\b(function|const|let|var|class|import|export|def|return|async|await)\b/i,
    /\b(error|bug|debug|compile|stack ?trace|exception|api|endpoint|json|sql|regex|html|css|javascript|typescript|python|node|react|kode|coding|script)\b/i,
    /[{};]\s*$/m, /=>|\(\)|\[\]/,
  ],
  creative: [
    /\b(cerita|puisi|lagu|lirik|novel|karakter|fiksi|imajinasi|bayangkan|dongeng|story|poem|lyrics|imagine|fiction|roleplay|slogan|nama bisnis|ide kreatif|brainstorm)\b/i,
    /\b(buatkan|tuliskan|karang)\b.*\b(cerita|puisi|lagu|caption|iklan)\b/i,
  ],
  analytical: [
    /\b(analisis|bandingkan|jelaskan|mengapa|kenapa|bagaimana cara|hitung|data|statistik|riset|penelitian|ringkas|rangkum|evaluasi|strategi|kelebihan|kekurangan|analyze|compare|explain|why|calculate|summarize)\b/i,
    /\d+\s*[%+\-*/=]\s*\d+/, /\b(tabel|grafik|rumus|persentase)\b/i,
  ],
  conversational: [
    /^(halo|hai|hi|hello|hey|pagi|siang|malam|terima kasih|makasih|thanks)\b/i,
    /\b(apa kabar|gimana|menurutmu|bantu aku|tolong|curhat)\b/i, /\?$/,
  ],
};

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));

export function detectContext(text: string, history: string[] = []): { context: ContextType; confidence: number; scores: Record<ContextType, number> } {
  const scores: Record<ContextType, number> = { code: 0, creative: 0, analytical: 0, conversational: 0.5 };
  const recent = history.slice(-4).join("\n");
  for (const ctx of Object.keys(PATTERNS) as ContextType[]) {
    for (const re of PATTERNS[ctx]) {
      if (re.test(text)) scores[ctx] += 2;      // pesan terbaru bobotnya lebih besar
      if (recent && re.test(recent)) scores[ctx] += 0.5;
    }
  }
  if (text.length < 25) scores.conversational += 1;
  const sorted = (Object.entries(scores) as [ContextType, number][]).sort((a, b) => b[1] - a[1]);
  const total = sorted.reduce((s, [, v]) => s + v, 0) || 1;
  return { context: sorted[0][0], confidence: clamp(sorted[0][1] / total, 0, 1), scores };
}

export type Strategy = "adaptive" | "precise" | "balanced" | "creative";

export function autoTune(opts: { message: string; history?: string[]; strategy?: Strategy }): TuneResult {
  const { message, history = [], strategy = "adaptive" } = opts;
  const det = detectContext(message, history);
  const notes: string[] = [];
  let context = det.context;

  if (strategy === "precise") { context = "code"; notes.push("Strategi manual: presisi"); }
  else if (strategy === "balanced") { context = "conversational"; notes.push("Strategi manual: seimbang"); }
  else if (strategy === "creative") { context = "creative"; notes.push("Strategi manual: kreatif"); }
  else notes.push(`Terdeteksi: ${context} (${Math.round(det.confidence * 100)}%)`);

  const p = { ...PROFILES[context] };

  // Kalau pendeteksi ragu, campur dengan profil seimbang supaya tidak ekstrem.
  if (strategy === "adaptive" && det.confidence < 0.45) {
    const b = PROFILES.conversational, w = det.confidence / 0.45;
    (Object.keys(p) as (keyof TuneParams)[]).forEach((k) => { p[k] = p[k] * w + b[k] * (1 - w); });
    notes.push("Keyakinan rendah: parameter dicampur dengan profil seimbang");
  }
  // Percakapan panjang cenderung mengulang kata.
  if (history.length >= 12) {
    p.repetition_penalty += 0.05; p.frequency_penalty += 0.1;
    notes.push("Percakapan panjang: penalti pengulangan dinaikkan");
  }

  return {
    context, confidence: det.confidence, scores: det.scores, notes,
    params: {
      temperature: +clamp(p.temperature, 0, 2).toFixed(2),
      top_p: +clamp(p.top_p, 0, 1).toFixed(2),
      top_k: Math.round(clamp(p.top_k, 0, 200)),
      frequency_penalty: +clamp(p.frequency_penalty, -2, 2).toFixed(2),
      presence_penalty: +clamp(p.presence_penalty, -2, 2).toFixed(2),
      repetition_penalty: +clamp(p.repetition_penalty, 0.5, 2).toFixed(2),
    },
  };
}
